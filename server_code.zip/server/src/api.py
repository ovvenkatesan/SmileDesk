import os
import uuid
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
from pydantic import BaseModel
from datetime import datetime, timedelta
from livekit.api import AccessToken, VideoGrants
from supabase import create_client, Client

load_dotenv()

app = FastAPI(title="Smile Garden Voice AI API")

# Initialize Supabase Client
supabase_url: str = os.getenv("NEXT_PUBLIC_SUPABASE_URL", "")
supabase_key: str = os.getenv("NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY", "")
supabase: Client | None = None
if supabase_url and supabase_key:
    supabase = create_client(supabase_url, supabase_key)

# Setup CORS for the dashboard
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, restrict to dashboard domain
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.responses import Response

@app.get("/")
def read_root():
    return {"message": "Smile Garden Voice AI API is running"}

@app.post("/api/vobiz-webhook")
async def vobiz_webhook():
    """
    Webhook for Vobiz to route incoming calls to LiveKit SIP.
    """
    xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Dial>
        <User>sip:smilegarden-j23vmzmq.livekit.cloud</User>
    </Dial>
</Response>"""
    return Response(content=xml_content, media_type="application/xml")

from livekit import api as livekit_api_module

@app.get("/api/token")
async def get_token():
    livekit_url = os.getenv("LIVEKIT_URL")
    livekit_api_key = os.getenv("LIVEKIT_API_KEY")
    livekit_api_secret = os.getenv("LIVEKIT_API_SECRET")

    if not all([livekit_url, livekit_api_key, livekit_api_secret]):
        raise HTTPException(status_code=500, detail="LiveKit credentials not configured on server")

    # Generate a unique participant ID but use a fixed room name for testing
    room_name = "test-web-room"
    participant_identity = f"user-{uuid.uuid4().hex[:8]}"

    grant = VideoGrants(room_join=True, room=room_name)
    access_token = AccessToken(
        livekit_api_key, livekit_api_secret
    ).with_identity(participant_identity).with_name("Web User").with_grants(grant).to_jwt()

    # Explicitly dispatch the agent to the room
    try:
        lk_api = livekit_api_module.LiveKitAPI(livekit_url, livekit_api_key, livekit_api_secret)
        await lk_api.agent_dispatch.create_dispatch(
            livekit_api_module.CreateAgentDispatchRequest(
                agent_name="pallavi-voice-agent",
                room=room_name
            )
        )
    except Exception as e:
        print(f"Error dispatching agent: {e}")
    finally:
        await lk_api.aclose()

    return {
        "token": access_token,
        "url": livekit_url,
        "room": room_name
    }

@app.get("/api/dashboard/roi")
def get_roi_snapshot():
    # Mock data
    return {
        "leads_saved": 42,
        "estimated_value": 8400, # e.g. 42 leads * $200 average value
        "period": "Last 30 Days"
    }

@app.get("/api/dashboard/agent-status")
def get_agent_status():
    # Mock data
    return {
        "status": "online",
        "last_active": datetime.now().isoformat()
    }

@app.get("/api/dashboard/calls")
def get_call_logs():
    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase not configured")
    try:
        response = supabase.table("calls").select("*").order("start_time", desc=True).execute()
        return response.data
    except Exception as e:
        print(f"Error fetching calls: {e}")
        raise HTTPException(status_code=500, detail="Error fetching calls from database")

@app.get("/api/dashboard/calls/{call_id}")
def get_call_details(call_id: str):
    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase not configured")
    try:
        response = supabase.table("calls").select("*").eq("id", call_id).execute()
        if not response.data:
            raise HTTPException(status_code=404, detail="Call not found")
        return response.data[0]
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error fetching call details: {e}")
        raise HTTPException(status_code=500, detail="Error fetching call details")

@app.get("/api/dashboard/bookings")
def get_booking_history():
    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase not configured")
    try:
        response = supabase.table("bookings").select("*").order("date", desc=True).execute()
        return response.data
    except Exception as e:
        print(f"Error fetching bookings: {e}")
        raise HTTPException(status_code=500, detail="Error fetching bookings from database")
