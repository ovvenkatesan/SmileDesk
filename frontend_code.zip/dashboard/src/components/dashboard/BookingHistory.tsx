"use client";

import { useEffect, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";

export function BookingHistory() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchBookings = () => {
    fetch(`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/api/dashboard/bookings`)
      .then((res) => res.json())
      .then((data) => {
        setBookings(data);
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching Bookings:", err);
        setIsLoading(false);
      });
  };

  useEffect(() => {
    fetchBookings();
    
    // Auto-refresh every 10 seconds to catch new bookings made by the voice agent
    const interval = setInterval(fetchBookings, 10000);
    return () => clearInterval(interval);
  }, []);

  if (isLoading && bookings.length === 0) {
    return <div className="p-4 text-sm text-muted-foreground animate-pulse">Loading bookings...</div>;
  }

  if (bookings.length === 0) {
    return <div className="p-4 text-sm text-muted-foreground">No recent bookings found.</div>;
  }

  return (
    <ScrollArea className="h-full">
      <div className="space-y-4 pr-4">
        {bookings.map((booking) => (
          <div key={booking.id} className="p-3 border rounded-lg bg-card hover:border-primary transition-colors">
            <div className="flex justify-between items-start mb-2">
              <div>
                <span className="font-semibold text-sm block">{booking.patient_number}</span>
                <span className="text-xs text-muted-foreground">{booking.type}</span>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full ${booking.status === 'Cancelled' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                {booking.status}
              </span>
            </div>
            <div className="text-sm text-foreground font-medium">
              {new Date(booking.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
            </div>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}